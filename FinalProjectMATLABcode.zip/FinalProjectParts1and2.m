%% Final Project Parts 1 and 2:  Reactive Ion Etching with MIMO Control
clc
close all
% Plant Model from [Power; Throttle] to [|F|; Vbias]
P1 = [tf([0.17 0.7],[1 15 26.7]); tf(0.28,[1 0.97])];
P2 = [tf(-0.17,[1 0.24]); tf([2.41 9.75],[1 4 0.7])];
P2.InputDelay = 0.5;
P = [P1 P2];

% Normalized System
DO = diag([30 350]);
DI = diag([1000 12.5]);
PN = inv(DO)*P*DI;
PN = ss(PN);

% Use second-order Pade approximation for input delay
PN = pade(PN,2);
PN.InputName = 'u';
PN.OutputName = 'y';

% State-space matrices and dimensions
[AP,BP,CP,DP] = ssdata(PN);
[nx,nu] = size(BP);
ny = size(CP,1);

%% Part 1(A): Linear Quadratic Regulator with Integrators
close all;
clc;
% Augment state equations so that you can do integral control
Aaug = [AP, zeros(nx,ny);
        CP, zeros(ny,ny)];
Baug = [BP;zeros(ny,nu)];
Caug = [CP,zeros(ny,ny)];
Daug = DP;
% LQR Weighting Matrices

Q1 = [3,0;
      0,3];
Q = CP'*Q1*CP;
Q_I = [1/3,0
       0,1/3];
Qaug = [Q,zeros(nx,ny);
        zeros(ny,nx),Q_I];
Raug = [1,0;
        0,2];

% Q1 = [1,0;
%       0,1];
% Q = CP'*Q1*CP;
% Q_I = [1,0
%        0,1];
% Qaug = [Q,zeros(nx,ny);
%         zeros(ny,nx),Q_I];
% Raug = eye(2);

% Qaug = eye(10);
% Raug = eye(2);


% LQ state feedback gain
Klqr = lqr(Aaug,Baug,Qaug,Raug);
K = Klqr(1:ny,1:nx);
KI = Klqr(1:ny,nx+1:size(Klqr,2));
% Closed loop state equations with state feedback and integrators.
Acl = Aaug-Baug*Klqr;
Bcl = [zeros(nx,ny);-eye(2)];
Ccl = Caug;
Cks = Klqr;
Dcl = Daug;
% Verify that closed-loop is stable (Check to verify no bugs in code)
T = ss(Acl,Bcl,Ccl,Dcl);
KS = ss(Acl,Bcl,Cks,Dcl);
isstable(T(1,1))
isstable(T(2,2))

% Lsf = ss(Aaug,Baug,Kaug,0);
% Tsf = feedback(Lsf,1);

% Time vector
% Tf = 50;
% Nt = 500;
Tf = 100;
Nt = 1000;
t = linspace(0,Tf,Nt);

% Step responses
figure;
bodemag(T(1,1));grid on;

y11 = step(T(1,1),t);
y21 = step(T(2,1),t);
u11 = step(KS(1,1),t);
u21 = step(KS(2,1),t);
y12 = step(T(1,2),t);
y22 = step(T(2,2),t);
u12 = step(KS(1,2),t);
u22 = step(KS(2,2),t);

figure();
subplot(2,2,1);
plot(t,y11,'b',t,y21,'r-.'); 
grid on; xlim([0, Tf])
legend('|F|','Vbias','Location','Southeast'); 
title('Step to |F|');
if exist('garyfyFigure','file'), garyfyFigure, end

subplot(2,2,2);
plot(t,u11,'b',t,u21,'r-.'); 
grid on; xlim([0, Tf])
legend('RF Power','Throttle','Location','Southeast'); 
title('Step to |F|');
if exist('garyfyFigure','file'), garyfyFigure, end

subplot(2,2,3);
plot(t,y12,'b',t,y22,'r-.'); 
grid on; xlim([0, Tf])
legend('|F|','Vbias','Location','Southeast'); 
title('Step to Vbias');
if exist('garyfyFigure','file'), garyfyFigure, end

subplot(2,2,4);
plot(t,u12,'b',t,u22,'r-.'); 
grid on; xlim([0, Tf])
legend('RF Power','Throttle','Location','Southeast'); 
title('Step to Vbias');
if exist('garyfyFigure','file'), garyfyFigure, end
%% Part 1(B): Linear Quadratic Regulator with Integrators
close all;
clc;
% Covariance matrices for loop transfer recovery observer
betavals = [10 100 1000];
Nb = numel(betavals);
% Observer gain
% Note: We only need to estimate the plant states. We do not need the
% observer to construct an estimate of the integrator states.
beta=betavals(1);
W = diag([0.01,0.01]);

L = lqr(AP',CP',1000^2*(BP*BP'),W)';    % 1000^2*(BP*BP'),W

% Verify that observer error is stable (Check to verify no bugs in code)
eig(AP-L*CP);

% Construct controller: 
% This includes the observer, integrators, and feedback gains.
%   Inputs: [|F| Ref.; Vbias Ref; |F| measurement; Vbias measurement]
%   Outputs: [Power; Throttle]
Aobs = [AP,-BP*K,-BP*KI;
        zeros(nx,nx),AP-BP*K-L*CP,-BP*KI;
        zeros(ny,nx),zeros(ny,10)]; % CP
Bobs = [zeros(8,2),zeros(8,2);
        zeros(8,2),L;
        -eye(2),eye(2)]; % zeros(2,2)
Cobs = [zeros(2,8),-K,-KI];
Dobs = 0;
Kobs = ss(Aobs,Bobs(:,3:4),Cobs,Dobs);

% Form Closed-Loop
%   Inputs are [|F| Ref.; Vbias Ref; |F| noise; Vbias noise]
%   Outputs: [|F|; Vbias; Power; Throttle]
Aosf = [AP-BP*K,BP*K,-BP*KI;
        zeros(nx,nx),AP-L*CP,zeros(8,2);
        CP,zeros(ny,10)];
Bosf = [zeros(8,2),zeros(8,2);
        zeros(8,2),-L;
        -eye(2),eye(2)]; % zeros(2,2)

Cosf = [CP,zeros(ny,10);
        -K,K,-KI]; % zeros(ny,nx)
Dosf = 0;

Posf = ss(Aosf,Bosf,Cosf,Dosf);

Tosf = Posf(1:2,:);
Kosf = Posf(3:4,:);

% Verify that closed-loop eigenvalues are the union of the observer
% and state-feedback eigenvalues. This is a useful debugging step
% to verify that you have correctly formed the closed-loop.
isstable(Posf)
% Step responses with noise on |F|
Tf = 50;
Nt = 500;
t = linspace(0,Tf,Nt);
stepinput = ones(1,Nt);
stepzeros = zeros(1,Nt);
Fnoise = 0.1*randn(1,Nt);

y11 = lsim(Tosf(1,1),stepinput',t)+lsim(Tosf(1,3),Fnoise',t);
y21 = lsim(Tosf(2,1),stepinput',t)+lsim(Tosf(2,3),Fnoise',t);
u11 = lsim(Kosf(1,1),stepinput',t)+lsim(Kosf(1,3),Fnoise',t);
u21 = lsim(Kosf(2,1),stepinput',t)+lsim(Kosf(2,3),Fnoise',t);

y12 = lsim(Tosf(1,2),stepinput',t)+lsim(Tosf(1,4),Fnoise',t);
y22 = lsim(Tosf(2,2),stepinput',t)+lsim(Tosf(2,4),Fnoise',t);
u12 = lsim(Kosf(1,2),stepinput',t)+lsim(Kosf(1,4),Fnoise',t);
u22 = lsim(Kosf(2,2),stepinput',t)+lsim(Kosf(2,4),Fnoise',t);

figure();
subplot(2,2,1);
plot(t,y11,'b',t,y21,'r-.'); 
grid on; xlim([0, Tf])
legend('|F|','Vbias','Location','Southeast'); 
title('Step to |F|');

subplot(2,2,2);
plot(t,u11,'b',t,u21,'r-.'); 
grid on; xlim([0, Tf])
legend('RF Power','Throttle','Location','Southeast'); 
title('Step to |F|');

subplot(2,2,3);
plot(t,y12,'b',t,y22,'r-.'); 
grid on; xlim([0, Tf])
legend('|F|','Vbias','Location','Southeast'); 
title('Step to Vbias');

subplot(2,2,4);
plot(t,u12,'b',t,u22,'r-.'); 
grid on; xlim([0, Tf])
legend('RF Power','Throttle','Location','Southeast'); 
title('Step to Vbias');

% Bode magnitude from |F| noise to [|F|; Vbias; Power; Throttle]
figure;
bodemag(Posf(1,3),'-');hold on;grid on;
bodemag(Posf(2,3),'--');
bodemag(Posf(3,3),'-.');
bodemag(Posf(4,3),':');hold off;
legend('[F]','Vbias','Power','Throttle');
% Sigma magnitude from [|F| Ref.; Vbias Ref] to [Power; Throttle]

% figure;
% sigma(Kosf(1,1));hold on;grid on;
% sigma(Kosf(1,2));
% sigma(Kosf(2,1));
% sigma(Kosf(2,2));hold off;
% sigma(Kosf);

% Sigma magnitude from [|F| Noise; Vbias Noise] to [Power; Throttle]



%% Part 1(D): Stability Margins and Comparison With State Feedback
clc
close all
Kaug = [K,KI];
Lsf = ss(Aaug,Baug,Kaug,0); 
Tsf = feedback(Lsf,eye(2));
Ssf = feedback(eye(2),Lsf);

% ss(AP,BP,CP,DP) ss(Aaug,Baug,Caug,Daug) 
Pobs = ss(Aaug,Baug,Caug,Daug) ;
Lobs = Kobs*Pobs;
Tobs = feedback(Lobs,eye(2));
Sobs = feedback(eye(2),Lobs);

% Loop-at-a-time margins at the plant input
AM = allmargin(Lsf);
AM(1)
AM(2)
[DMI, MMI] = diskmargin(Lsf);
DMI(1)
DMI(2)
MMI
% Unstructured (fully-coupled) stability margin (USM) at the plant input
1/norm(Lsf,inf)

% Input loop transfer function: Compare Lsf to Lobs
figure;
sigma(Lsf);hold on;grid on;
sigma(Lobs);
title("Lsf & Lobs");
legend('sf','obs');

% Input sensitivity: Compare Ssf to Sobs
figure;
sigma(Ssf);hold on;grid on;
sigma(Sobs);
title("Ssf & Sobs");
legend('sf','obs');

% Input complementary sensitivity: Compare Tsf to Tosf
figure;
sigma(Tsf);hold on;grid on;
sigma(Tosf);
title("Tsf & Tosf");
legend('sf','obs');

%% Part 2(B): Equivalent Controller

% Equivalent controller
%   Ceq = inv[ I+K1 inv(Sobs-A) B] (KI/s)



%% Part 2(C): Decentralized Approximation of Equivalent Controller




%% Part 2: Comment on Plant Transformation
M = [1 1; -1 1]/sqrt(2);
MP = M*PN;

figure(12)
subplot(2,1,1)
bodemag(PN(1,1),'b',PN(1,2),'r--',PN(2,1),'m-.',PN(2,2),'g-.',{1e-2,1e2});
legend('PN(1,1)','PN(1,2)','PN(2,1)','PN(2,2)','Location','Southwest');
grid on;
if exist('garyfyFigure','file'), garyfyFigure, end

subplot(2,1,2)
bodemag(MP(1,1),'b',MP(1,2),'r--',MP(2,1),'m-.',MP(2,2),'g-.',{1e-2,1e2});
legend('MP(1,1)','MP(1,2)','MP(2,1)','MP(2,2)','Location','Southwest');
grid on;
if exist('garyfyFigure','file'), garyfyFigure, end

