%% Final Project Part 3:  Reactive Ion Etching with MIMO Control

%% Part 3(A) -- DC Analysis With Oxygen Sensor
close all
clc
% Model
% Inputs: [Power; Throttle; %O2]
% Outputs: [|F|; Vbias; Pressure]
P1 = [zpk(-0.067,[-0.095 -19.69],0.49); ...
    zpk(-0.27,[-0.19 -62.42],12.23); ...
    zpk(0.006,[-0.19 -2.33],-0.011)];

P2 = [zpk(0.73,[-0.11; -39.76],4.85); tf(1.65,[1 0.16]); ...
      zpk([],[-0.18; -3],-0.97)];
P2.InputDelay = 0.42;

P3 = [tf(0.33,[1 0.17]); tf(0.25,[1 0.41]); tf(0.024,[1 0.4])];
P3.InputDelay = 0.77;

Pox = [P1 P2 P3];

% Use second-order Pade for plant
Pox = pade(Pox, 2);

% Input and output scalings based on equilibrium values
DO = diag([16.52 340 17.83]);
DI = diag([1000 12.5 5]);
% Normalize Plant
PN = inv(DO)*Pox*DI;
PN = ss(PN);

% Condition number of DC gain
PNDC = dcgain(PN);
[U,sigma,V] = svd(PNDC);
singular_values = diag(sigma);
condition_number = max(singular_values)/min(singular_values)
%% Part 3(B) -- DC Analysis With Oxygen Sensor
clc
close all
% State-space data for scaled plant
[As,Bs,Cs,Ds] = ssdata(PN);
[nx,nu] = size(Bs);
ny = size(Cs,1);

% Weighting matrices (Q,R,V,W)
% Assume Q of the form Q = blkdiag(alpha*Cs'*Cs, Qw)
Q1 = diag([1.5,2,1]);
Qw = diag([1,1.5,1]);
Q = blkdiag(Cs'*Q1*Cs, Qw);
R = diag([2,2,1]);
V = Bs*Bs';
W = eye(3);

% Augmented Plant with integrators
Aaug = [As, zeros(nx,ny);
        Cs, zeros(ny,ny)];
Baug = [Bs; zeros(ny,nu)];
Caug = [Cs, zeros(ny,ny)];
Daug = Ds;

% Compute state feedback and observer gains
K_lqr = lqr(Aaug,Baug,Q,R);
K = K_lqr(1:ny,1:nx);
KI = K_lqr(1:ny,nx+1:size(K_lqr,2));

L = lqr(As',Cs',V, W)';

% Construct controller:
% This includes the observer, integrators, and feedback gains.
%   Inputs: [|F|Ref; Vbias Ref; Press Ref; |F| Meas; Vbias Meas; Press Meas]
%   Outputs: [Power; Throttle; %O2]
Aobs = [As,-Bs*K,-Bs*KI;
        zeros(nx,nx),As-Bs*K-L*Cs,-Bs*KI;
        zeros(ny,55)]; % Cs
Bobs = [zeros(nx,nu),zeros(nx,nu);
        zeros(nx,nu),L;
        -eye(nu),eye(nu)]; % zeros(2,2)
Cobs = [zeros(ny,nx),-K,-KI];
Dobs = 0;
Kobs = ss(Aobs,Bobs(:,3:4),Cobs,Dobs);
% Form Closed-Loop
%   Inputs: [|F|Ref; Vbias Ref; Press Ref; |F| Noise; Vbias Noise; Press Noise]
%   Outputs: [|F|; Vbias; Press; Power; Throttle; %O2]
Aosf = [As-Bs*K,Bs*K,-Bs*KI;
        zeros(nx,nx),As-L*Cs,zeros(nx,nu);
        Cs,zeros(ny,55-26)];
Bosf = [zeros(nx,nu),zeros(nx,nu);
        zeros(nx,nu),-L;
        -eye(nu),eye(nu)]; % zeros(2,2)

Cosf = [Cs,zeros(ny,55-26);
        -K,K,-KI]; % zeros(ny,nx)
Dosf = 0;

Posf = ss(Aosf,Bosf,Cosf,Dosf);

Tobs = Posf(1:3,:);
Kobs = Posf(4:6,:);
% Verify that closed-loop eigenvalues are the union of the observer
% and state-feedback eigenvalues. This is a useful debugging step
% to verify that you have correctly formed the closed-loop.
sort(eig(Aosf))
union(eig(As-Bs*K),eig(As-L*Cs))
isstable(Posf)
% Time vector
Tf = 40;
Nt = 400;
t = linspace(0,Tf,Nt);
% Step Responses (Without Noise)
y11 = step(Tobs(1,1),t);
y21 = step(Tobs(2,1),t);
y31 = step(Tobs(3,1),t);
u11 = step(Kobs(1,1),t);
u21 = step(Kobs(2,1),t);
u31 = step(Kobs(3,1),t);
y12 = step(Tobs(1,2),t);
y22 = step(Tobs(2,2),t);
y32 = step(Tobs(3,2),t);
u12 = step(Kobs(1,2),t);
u22 = step(Kobs(2,2),t);
u32 = step(Kobs(3,2),t);
y13 = step(Tobs(1,3),t);
y23 = step(Tobs(2,3),t);
y33 = step(Tobs(3,3),t);
u13 = step(Kobs(1,3),t);
u23 = step(Kobs(2,3),t);
u33 = step(Kobs(3,3),t);
figure();
subplot(2,3,1);
plot(t,y11,'b',t,y21,'r-.',t,y31,'m:');
grid on; xlim([0, Tf])
title('Step to |F|');
subplot(2,3,4);
plot(t,u11,'b',t,u21,'r-.',t,u31,'m:');
grid on; xlim([0, Tf])
title('Step to |F|');
subplot(2,3,2);
plot(t,y12,'b',t,y22,'r-.',t,y32,'m:');
grid on; xlim([0, Tf])
title('Step to Vbias');
subplot(2,3,5);
plot(t,u12,'b',t,u22,'r-.',t,u32,'m:');
grid on; xlim([0, Tf])
title('Step to Vbias');
subplot(2,3,3);
plot(t,y13,'b',t,y23,'r-.',t,y33,'m:');
grid on; xlim([0, Tf])
legend('|F|','Vbias','Pressure','Location','best');
title('Step to Pressure');
subplot(2,3,6);
plot(t,u13,'b',t,u23,'r-.',t,u33,'m:');
grid on; xlim([0, Tf])
legend('RF Power','Throttle','%O_2','Location','best');
title('Step to %O_2');
